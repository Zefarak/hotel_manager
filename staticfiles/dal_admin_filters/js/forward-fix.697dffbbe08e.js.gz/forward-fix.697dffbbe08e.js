(function ($) {
    $(document).ready(function () {
        $('#changelist-filter').children().wrapAll('<form></form>'); // required for forward func
    });
})(django.jQuery);
